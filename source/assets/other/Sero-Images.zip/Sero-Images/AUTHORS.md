Authors:

* Max O'Brien
  Art Direction and Illustrator