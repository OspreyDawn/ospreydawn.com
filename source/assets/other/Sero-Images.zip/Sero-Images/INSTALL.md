Installation Instructions
-------------------------

Decompress the bundled files to a local directory and enjoy.

License
-------

Sero UX Design files are released under the terms of the Creative Commons license. See 
`LICENSE` for more information or see http://creativecommons.org/licenses/by-nc-sa/3.0/

Copyright (c) 2014, Max O'Brien <max@ospreydawn.com>

Copying and distribution of this file, with or without modification, are permitted in any 
medium without royalty provided the copyright notice and this notice are preserved.  
These files is offered as-is, without warranty of any kind.

Required Software
-----------------

The original graphic illustration has been done in Adobe Illustrator CS6. Only renders of images have been made available.

